import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Alert } from 'react-native';

// Configuração dos níveis de dificuldade
const levels = {
  facil: { velocidade: 1000 },
  medio: { velocidade: 700 },
  dificil: { velocidade: 400 }
};

const GeniusGame = () => {
  // Estados do jogo
  const [sequence, setSequence] = useState([]); // Sequência gerada pelo jogo
  const [playerInput, setPlayerInput] = useState([]); // Entrada do jogador
  const [isPlaying, setIsPlaying] = useState(false); // Status do jogo
  const [nivel, setNivel] = useState('facil'); // Nível selecionado
  const [activeButton, setActiveButton] = useState(null); // Indica o botão que está piscando
  const [pontos, setPontos] = useState(0); // Pontuação do jogador

  // Função para iniciar o jogo
  const iniciarJogo = () => {
    setSequence([Math.floor(Math.random() * 9)]); // Inicia com um único número aleatório
    setPlayerInput([]);
    setPontos(0);
    setIsPlaying(true);
  };

  // Adiciona um novo número à sequência existente
  const adicionarPasso = () => {
    setSequence(prevSequence => [...prevSequence, Math.floor(Math.random() * 9)]);
    setPlayerInput([]);
  };

  // Reproduz a sequência piscando os botões
  useEffect(() => {
    if (isPlaying && sequence.length > 0) {
      reproduzirSequencia(sequence);
    }
  }, [sequence, isPlaying]);

  const reproduzirSequencia = (seq) => {
    seq.forEach((num, index) => {
      setTimeout(() => {
        setActiveButton(num);
        setTimeout(() => setActiveButton(null), levels[nivel].velocidade / 2);
      }, index * levels[nivel].velocidade);
    });
  };

  // Lida com os cliques do jogador
  const lidarComClique = (num) => {
    if (!isPlaying) return; // Impede interações se o jogo não estiver ativo

    const novoInput = [...playerInput, num];
    setPlayerInput(novoInput);

    // Verifica se a entrada do jogador está correta
    if (novoInput.join('') === sequence.slice(0, novoInput.length).join('')) {
      if (novoInput.length === sequence.length) {
        setPontos(pontos + 1);
        setTimeout(() => {
          adicionarPasso();
        }, 1000);
      }
    } else {
      // Mensagem de erro quando o jogador erra a sequência
      setIsPlaying(false);
      Alert.alert('Erro!', `Você errou a sequência! Pontuação final: ${pontos}\nTente novamente.`, [
        { text: 'OK' }
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Jogo Genius</Text>
      <Text style={styles.score}>Pontuação: {pontos}</Text>

      {/* Botões para selecionar o nível de dificuldade */}
      <View style={styles.levelContainer}>
        {Object.keys(levels).map((lvl) => (
          <TouchableOpacity
            key={lvl}
            style={[styles.levelButton, nivel === lvl && styles.activeLevel]}
            onPress={() => setNivel(lvl)}
          >
            <Text style={styles.levelText}>{lvl.toUpperCase()}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Grade 3x3 de botões */}
      <View style={styles.grid}>
        {[...Array(9)].map((_, i) => (
          <TouchableOpacity
            key={i}
            style={[styles.button, activeButton === i && styles.activeButton]}
            onPress={() => lidarComClique(i)}
          />
        ))}
      </View>

      {/* Botão para iniciar o jogo */}
      {!isPlaying && (
        <TouchableOpacity style={styles.startButton} onPress={iniciarJogo}>
          <Text style={styles.startText}>Iniciar Jogo</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  score: { fontSize: 18, marginBottom: 10 },
  levelContainer: { flexDirection: 'row', marginBottom: 10 },
  levelButton: { padding: 10, margin: 5, backgroundColor: 'gray', borderRadius: 5 },
  activeLevel: { backgroundColor: 'blue' },
  levelText: { color: 'white', fontWeight: 'bold' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', width: 156, height: 156, justifyContent: 'center' },
  button: { width: 50, height: 50, margin: 1, backgroundColor: 'gray', justifyContent: 'center', alignItems: 'center' },
  activeButton: { backgroundColor: 'yellow' },
  startButton: { marginTop: 20, padding: 10, backgroundColor: 'blue', borderRadius: 5 },
  startText: { color: 'white', fontWeight: 'bold' }
});

export default GeniusGame;
